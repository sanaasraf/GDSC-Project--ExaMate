import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'sana_record.g.dart';

abstract class SanaRecord implements Built<SanaRecord, SanaRecordBuilder> {
  static Serializer<SanaRecord> get serializer => _$sanaRecordSerializer;

  @BuiltValueField(wireName: 'Marks')
  int? get marks;

  @BuiltValueField(wireName: 'Answer')
  String? get answer;

  String? get uid;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  DocumentReference get parentReference => reference.parent.parent!;

  static void _initializeBuilder(SanaRecordBuilder builder) => builder
    ..marks = 0
    ..answer = ''
    ..uid = '';

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Sana')
          : FirebaseFirestore.instance.collectionGroup('Sana');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('Sana').doc();

  static Stream<SanaRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<SanaRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  SanaRecord._();
  factory SanaRecord([void Function(SanaRecordBuilder) updates]) = _$SanaRecord;

  static SanaRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createSanaRecordData({
  int? marks,
  String? answer,
  String? uid,
}) {
  final firestoreData = serializers.toFirestore(
    SanaRecord.serializer,
    SanaRecord(
      (s) => s
        ..marks = marks
        ..answer = answer
        ..uid = uid,
    ),
  );

  return firestoreData;
}
