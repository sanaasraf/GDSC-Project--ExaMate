import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'nimrah_record.g.dart';

abstract class NimrahRecord
    implements Built<NimrahRecord, NimrahRecordBuilder> {
  static Serializer<NimrahRecord> get serializer => _$nimrahRecordSerializer;

  @BuiltValueField(wireName: 'Marks')
  int? get marks;

  @BuiltValueField(wireName: 'Answer')
  String? get answer;

  String? get uid;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  DocumentReference get parentReference => reference.parent.parent!;

  static void _initializeBuilder(NimrahRecordBuilder builder) => builder
    ..marks = 0
    ..answer = ''
    ..uid = '';

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Nimrah')
          : FirebaseFirestore.instance.collectionGroup('Nimrah');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('Nimrah').doc();

  static Stream<NimrahRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<NimrahRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  NimrahRecord._();
  factory NimrahRecord([void Function(NimrahRecordBuilder) updates]) =
      _$NimrahRecord;

  static NimrahRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createNimrahRecordData({
  int? marks,
  String? answer,
  String? uid,
}) {
  final firestoreData = serializers.toFirestore(
    NimrahRecord.serializer,
    NimrahRecord(
      (n) => n
        ..marks = marks
        ..answer = answer
        ..uid = uid,
    ),
  );

  return firestoreData;
}
