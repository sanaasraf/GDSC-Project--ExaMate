// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nimrah_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<NimrahRecord> _$nimrahRecordSerializer =
    new _$NimrahRecordSerializer();

class _$NimrahRecordSerializer implements StructuredSerializer<NimrahRecord> {
  @override
  final Iterable<Type> types = const [NimrahRecord, _$NimrahRecord];
  @override
  final String wireName = 'NimrahRecord';

  @override
  Iterable<Object?> serialize(Serializers serializers, NimrahRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.marks;
    if (value != null) {
      result
        ..add('Marks')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.answer;
    if (value != null) {
      result
        ..add('Answer')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.uid;
    if (value != null) {
      result
        ..add('uid')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  NimrahRecord deserialize(
      Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new NimrahRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'Marks':
          result.marks = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int?;
          break;
        case 'Answer':
          result.answer = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'uid':
          result.uid = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$NimrahRecord extends NimrahRecord {
  @override
  final int? marks;
  @override
  final String? answer;
  @override
  final String? uid;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$NimrahRecord([void Function(NimrahRecordBuilder)? updates]) =>
      (new NimrahRecordBuilder()..update(updates))._build();

  _$NimrahRecord._({this.marks, this.answer, this.uid, this.ffRef}) : super._();

  @override
  NimrahRecord rebuild(void Function(NimrahRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  NimrahRecordBuilder toBuilder() => new NimrahRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is NimrahRecord &&
        marks == other.marks &&
        answer == other.answer &&
        uid == other.uid &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    var _$hash = 0;
    _$hash = $jc(_$hash, marks.hashCode);
    _$hash = $jc(_$hash, answer.hashCode);
    _$hash = $jc(_$hash, uid.hashCode);
    _$hash = $jc(_$hash, ffRef.hashCode);
    _$hash = $jf(_$hash);
    return _$hash;
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'NimrahRecord')
          ..add('marks', marks)
          ..add('answer', answer)
          ..add('uid', uid)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class NimrahRecordBuilder
    implements Builder<NimrahRecord, NimrahRecordBuilder> {
  _$NimrahRecord? _$v;

  int? _marks;
  int? get marks => _$this._marks;
  set marks(int? marks) => _$this._marks = marks;

  String? _answer;
  String? get answer => _$this._answer;
  set answer(String? answer) => _$this._answer = answer;

  String? _uid;
  String? get uid => _$this._uid;
  set uid(String? uid) => _$this._uid = uid;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  NimrahRecordBuilder() {
    NimrahRecord._initializeBuilder(this);
  }

  NimrahRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _marks = $v.marks;
      _answer = $v.answer;
      _uid = $v.uid;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(NimrahRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$NimrahRecord;
  }

  @override
  void update(void Function(NimrahRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  NimrahRecord build() => _build();

  _$NimrahRecord _build() {
    final _$result = _$v ??
        new _$NimrahRecord._(
            marks: marks, answer: answer, uid: uid, ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
