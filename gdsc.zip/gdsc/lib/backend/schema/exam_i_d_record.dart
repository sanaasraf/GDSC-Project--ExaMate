import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'exam_i_d_record.g.dart';

abstract class ExamIDRecord
    implements Built<ExamIDRecord, ExamIDRecordBuilder> {
  static Serializer<ExamIDRecord> get serializer => _$examIDRecordSerializer;

  @BuiltValueField(wireName: 'GDSC')
  String? get gdsc;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(ExamIDRecordBuilder builder) =>
      builder..gdsc = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Exam_ID');

  static Stream<ExamIDRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<ExamIDRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  ExamIDRecord._();
  factory ExamIDRecord([void Function(ExamIDRecordBuilder) updates]) =
      _$ExamIDRecord;

  static ExamIDRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createExamIDRecordData({
  String? gdsc,
}) {
  final firestoreData = serializers.toFirestore(
    ExamIDRecord.serializer,
    ExamIDRecord(
      (e) => e..gdsc = gdsc,
    ),
  );

  return firestoreData;
}
