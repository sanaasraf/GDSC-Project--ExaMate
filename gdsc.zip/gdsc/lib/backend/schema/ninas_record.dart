import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'ninas_record.g.dart';

abstract class NinasRecord implements Built<NinasRecord, NinasRecordBuilder> {
  static Serializer<NinasRecord> get serializer => _$ninasRecordSerializer;

  @BuiltValueField(wireName: 'Marks')
  int? get marks;

  @BuiltValueField(wireName: 'Answer')
  String? get answer;

  String? get uid;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  DocumentReference get parentReference => reference.parent.parent!;

  static void _initializeBuilder(NinasRecordBuilder builder) => builder
    ..marks = 0
    ..answer = ''
    ..uid = '';

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Ninas')
          : FirebaseFirestore.instance.collectionGroup('Ninas');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('Ninas').doc();

  static Stream<NinasRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<NinasRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  NinasRecord._();
  factory NinasRecord([void Function(NinasRecordBuilder) updates]) =
      _$NinasRecord;

  static NinasRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createNinasRecordData({
  int? marks,
  String? answer,
  String? uid,
}) {
  final firestoreData = serializers.toFirestore(
    NinasRecord.serializer,
    NinasRecord(
      (n) => n
        ..marks = marks
        ..answer = answer
        ..uid = uid,
    ),
  );

  return firestoreData;
}
