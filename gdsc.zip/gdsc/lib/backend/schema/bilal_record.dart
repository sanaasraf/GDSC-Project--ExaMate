import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'bilal_record.g.dart';

abstract class BilalRecord implements Built<BilalRecord, BilalRecordBuilder> {
  static Serializer<BilalRecord> get serializer => _$bilalRecordSerializer;

  @BuiltValueField(wireName: 'Marks')
  int? get marks;

  @BuiltValueField(wireName: 'Answer')
  String? get answer;

  String? get uid;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  DocumentReference get parentReference => reference.parent.parent!;

  static void _initializeBuilder(BilalRecordBuilder builder) => builder
    ..marks = 0
    ..answer = ''
    ..uid = '';

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Bilal')
          : FirebaseFirestore.instance.collectionGroup('Bilal');

  static DocumentReference createDoc(DocumentReference parent) =>
      parent.collection('Bilal').doc();

  static Stream<BilalRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<BilalRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  BilalRecord._();
  factory BilalRecord([void Function(BilalRecordBuilder) updates]) =
      _$BilalRecord;

  static BilalRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createBilalRecordData({
  int? marks,
  String? answer,
  String? uid,
}) {
  final firestoreData = serializers.toFirestore(
    BilalRecord.serializer,
    BilalRecord(
      (b) => b
        ..marks = marks
        ..answer = answer
        ..uid = uid,
    ),
  );

  return firestoreData;
}
