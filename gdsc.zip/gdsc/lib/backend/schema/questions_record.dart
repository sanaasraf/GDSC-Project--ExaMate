import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'questions_record.g.dart';

abstract class QuestionsRecord
    implements Built<QuestionsRecord, QuestionsRecordBuilder> {
  static Serializer<QuestionsRecord> get serializer =>
      _$questionsRecordSerializer;

  @BuiltValueField(wireName: 'question_type')
  String? get questionType;

  String? get text;

  String? get answer;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(QuestionsRecordBuilder builder) => builder
    ..questionType = ''
    ..text = ''
    ..answer = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('questions');

  static Stream<QuestionsRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<QuestionsRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s))!);

  QuestionsRecord._();
  factory QuestionsRecord([void Function(QuestionsRecordBuilder) updates]) =
      _$QuestionsRecord;

  static QuestionsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createQuestionsRecordData({
  String? questionType,
  String? text,
  String? answer,
}) {
  final firestoreData = serializers.toFirestore(
    QuestionsRecord.serializer,
    QuestionsRecord(
      (q) => q
        ..questionType = questionType
        ..text = text
        ..answer = answer,
    ),
  );

  return firestoreData;
}
