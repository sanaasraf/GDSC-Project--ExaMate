import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyApWXyS5g7rT9q0qbL7EykeLf0SeH95ET8",
            authDomain: "exammate-ac0b8.firebaseapp.com",
            projectId: "exammate-ac0b8",
            storageBucket: "exammate-ac0b8.appspot.com",
            messagingSenderId: "146605467751",
            appId: "1:146605467751:web:d8310b75b57194b02a0cc2",
            measurementId: "G-9WRKJL4KF2"));
  } else {
    await Firebase.initializeApp();
  }
}
