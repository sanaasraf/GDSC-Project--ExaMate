package com.mycompany.gdsc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
